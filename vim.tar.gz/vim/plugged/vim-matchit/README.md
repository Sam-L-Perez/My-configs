matchit.vim
===========

I am not the author of this plugin, but my dotfiles were relying on it, and the
last Github user who was storing it in his name removed it.

Install
-------

With [Vundle](https://github.com/gmarik/vundle):

    Bundle 'geoffharcourt/vim-matchit'

License
-------

MIT
