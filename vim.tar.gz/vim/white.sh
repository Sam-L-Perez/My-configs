#!/bin/bash


echo "What the fuck white pepole"


sleep 10

echo  "Seriously you folks need brown jesus"

sleep 10


echo "s" 

sleep 2

echo "m"

sleep 4

echo "h"
